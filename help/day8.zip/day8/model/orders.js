const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    name: String,
    price: Number,
    category: String,
    userName: String,
});

const OrderModel = mongoose.model('orders', orderSchema);

module.exports = {
    OrderModel,
}
