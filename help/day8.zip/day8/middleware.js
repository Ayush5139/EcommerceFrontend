const { verifyToken } = require("./jwt");

function verifyTokenMiddleware(req, res, next) {
    const token = req.headers['token'];
    const userInfo = verifyToken(token);
    if (userInfo == null) {
        return res.status(403).send('token is incorrect');
    }

    req.userInfo = userInfo;

    next();
}

module.exports = {
    verifyTokenMiddleware
}
