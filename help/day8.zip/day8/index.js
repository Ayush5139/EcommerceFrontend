const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const router = require('./route/orders');
const userRouter = require('./route/users');
const { verifyTokenMiddleware } = require('./middleware');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

app.use('/orders', verifyTokenMiddleware);

app.use('/', router);
app.use('/users', userRouter);

// Connect to the MongoDB database
mongoose.connect('mongodb://localhost/amazondb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
    console.log('MongoDB is Connected...')
});


// start server
app.listen(PORT, () => {
    console.log(`server is running...${PORT}`);
});