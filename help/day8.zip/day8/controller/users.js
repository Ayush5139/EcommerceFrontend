const bcrypt = require('bcrypt');

const { UsersModel } = require("../model/users");
const { createToken } = require('../jwt');

function hashPassword(password) {
    const saltRounds = 10;
    return bcrypt.hashSync(password, saltRounds);
}

function isCorrectPassword(password, hash) {
    return bcrypt.compareSync(password, hash)
}

/**
 * {
		name: "rohit"
		email : "rohit@gmail.com"
		password : "rohitkumar"
		age: 24
	}
 */
async function createUser(req, res) {
    const userInfo = req.body;

    const hashpassword = hashPassword(userInfo.password);
    userInfo.password = hashpassword;

    const data = await UsersModel.create(userInfo);

    console.log(data);
    return res.send("created successfully");
}

//{
//	"email":"rohit@gmail.com"
//	"password":"rohitkumar"
//} 
//
async function loginUser(req, res) {
    const loginInfo = req.body;

    // find user in database using email id
    const userData = await UsersModel.findOne({ email : loginInfo.email });
    if (userData == null) {
        return res.status(403).send('wrong email, please try again');
    }


    const password = loginInfo.password;
    const hash = userData.password;

    const isCorrect = isCorrectPassword(password, hash);
    if (!isCorrect) {
        return res.status(403).send('wrong password, please try again');
    }

    const token = createToken({
        userId: userData._id,
        userName: userData.name,
        email: userData.email
    });

    return res.json({ token });
}

module.exports = {
    createUser,
    loginUser,
}