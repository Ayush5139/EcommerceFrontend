const { verifyToken } = require("../jwt");
const { OrderModel } = require("../model/orders");

async function getOrderByUserId(req, res) {
    console.log(req.userInfo);
    const data = await OrderModel.find({ userName: req.userInfo.userName });
    return res.json(data);
}

module.exports = {
    getOrderByUserId,
};
