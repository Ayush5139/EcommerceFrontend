const jwt = require('jsonwebtoken');
const secretKey = "amazonsecretkey";

function createToken(data) {
    const token = jwt.sign(data, secretKey, { expiresIn: '2h' });
    return token;
}

function verifyToken(token) {
    try {
        const data = jwt.verify(token, secretKey);
        return data;
    } catch (error) {
        return null;
    }
}

module.exports = {
    createToken,
    verifyToken,
}
