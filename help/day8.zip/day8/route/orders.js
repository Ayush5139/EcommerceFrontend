const express = require('express');
const { getOrderByUserId } = require('../controller/orders');

const orderRouter = express.Router();

orderRouter.get('/orders', getOrderByUserId);

module.exports = orderRouter;
